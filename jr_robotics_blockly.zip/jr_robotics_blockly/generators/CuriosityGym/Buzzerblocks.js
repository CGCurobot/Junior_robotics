Blockly.Blocks['control_buzzer'] = {
    init: function() {
      this.appendDummyInput()
          .appendField("Control Buzzer on Pin D5");
      this.appendDummyInput()
          .setAlign(Blockly.ALIGN_RIGHT)
          .appendField("Set Buzzer to")
          .appendField(new Blockly.FieldDropdown([["HIGH", "HIGH"], ["LOW", "LOW"]]), "state");
      this.setPreviousStatement(true, null);
      this.setNextStatement(true, null);
      this.setColour(260);
      this.setTooltip("Control a buzzer on pin D5 by setting it to HIGH or LOW.");
      this.setHelpUrl("");
    }
  };
  