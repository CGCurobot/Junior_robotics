Blockly.Arduino['control_buzzer'] = function(block) {
    var state = block.getFieldValue('state');
  
    // Set D5 pin as output
    Blockly.Arduino.setups_['setup_output_D5'] = 'pinMode(5, OUTPUT);';
  
    var code = 'digitalWrite(5, ' + state + ');\n';
    return code;
  };
  